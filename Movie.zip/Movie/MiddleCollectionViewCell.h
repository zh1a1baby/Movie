//
//  MiddleCollectionViewCell.h
//  Movie
//
//  Created by mac on 16/4/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MovieModel.h"

@interface MiddleCollectionViewCell : UICollectionViewCell

@property (strong,nonatomic)MovieModel *modelView;
-(void)cellFlip;
-(void)resetcell;
@end

//
//  NewsImageModel.h
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/26.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NewsImageModel : NSObject

@property (copy , nonatomic)NSString *image;


@end

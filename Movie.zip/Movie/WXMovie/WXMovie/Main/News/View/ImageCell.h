//
//  ImageCell.h
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/26.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsImageModel.h"

@interface ImageCell : UICollectionViewCell

@property (strong ,nonatomic)NewsImageModel *imageModel;

@end

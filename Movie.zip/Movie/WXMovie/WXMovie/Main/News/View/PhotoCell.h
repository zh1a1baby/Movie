//
//  PhotoCell.h
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/27.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsImageModel.h"

@interface PhotoCell : UICollectionViewCell

@property (strong, nonatomic)NewsImageModel *photoModel;

@end

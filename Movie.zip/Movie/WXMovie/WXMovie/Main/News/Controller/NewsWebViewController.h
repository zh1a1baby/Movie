//
//  NewsWebViewController.h
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/26.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "BaseViewController.h"

@interface NewsWebViewController : BaseViewController

@end

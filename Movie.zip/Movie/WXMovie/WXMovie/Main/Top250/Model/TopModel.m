//
//  TopModel.m
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/25.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "TopModel.h"

@implementation TopModel
//如果发现 Json文件中字典中的键 key 是关键字就需要重写这个方法
- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
    


}

@end

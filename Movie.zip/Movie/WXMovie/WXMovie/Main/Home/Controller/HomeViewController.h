//
//  HomeViewController.h
//  WXMovieZZJ
//
//  Created by zhongzhongjun on 16/4/17.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "BaseViewController.h"

@interface HomeViewController : BaseViewController

@end

//
//  LargeCollectionFlowLayout.h
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/22.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseCollectionViewFlowLayout.h"
@interface LargeCollectionFlowLayout : BaseCollectionViewFlowLayout

@end

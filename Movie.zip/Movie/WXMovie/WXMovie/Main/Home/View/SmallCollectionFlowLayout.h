//
//  SmallCollectionFlowLayout.h
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/23.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import "BaseCollectionViewFlowLayout.h"

@interface SmallCollectionFlowLayout : BaseCollectionViewFlowLayout

@end

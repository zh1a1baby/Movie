//
//  PostView.h
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/20.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostView : UIView
@property (strong ,nonatomic)NSArray *postMoviesData;

@end

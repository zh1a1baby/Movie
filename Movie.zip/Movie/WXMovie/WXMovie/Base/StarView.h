//
//  StarView.h
//  WXMovie
//
//  Created by zhongzhongjun on 16/4/20.
//  Copyright © 2016年 wxhl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StarView : UIView

@property (assign,nonatomic)float rating;

@end

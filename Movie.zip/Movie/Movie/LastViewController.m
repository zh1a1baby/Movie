//
//  LastViewController.m
//  Movie
//
//  Created by mac on 16/4/29.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "LastViewController.h"
#import "BaseTabBarController.h"
@interface LastViewController (){

    NSMutableArray *_imageArr;
    NSInteger _index;


}

@end

@implementation LastViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _index = 0;
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"timg.jpg"]];
    [self _createImageView];
    [self _startAnimation];
}

-(void)_startAnimation{
    
    
    if(_index >= _imageArr.count){//判断当到了最后一张图片的时候就切换根视图
        
        UIStoryboard *imageBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        BaseTabBarController *barController = [imageBoard instantiateInitialViewController];
    
        barController.view.transform = CGAffineTransformMakeScale(.2, .2);
        
        [UIView animateWithDuration:1 animations:^{
            barController.view.transform = CGAffineTransformIdentity;

        }];
        
        self.view.window.rootViewController = barController;
    
        return;
    }

    
    //每次取出对应的一张图片_index加1
    UIImageView *imageViews = _imageArr[_index++];
    
    //修改透明度
    [UIView animateWithDuration:.2 animations:^{
        imageViews.alpha = 1;
        
    }];

    [self performSelector:@selector(_startAnimation) withObject:self afterDelay:.2];

}


-(void)_createImageView{

    CGFloat widht = KScreenwidh/4;//每一行的图片个数
    CGFloat height = KScreenheight/7;//每一列的图片个数
    
    CGFloat count = 28;//整个视图的图片总数
    
    CGFloat x = 0;//计算每一张图片x轴的坐标
    CGFloat y = 0;//计算每一列 Y轴的坐标
    
    _imageArr =[NSMutableArray array];

    for (int i = 0; i < count; i++) {
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, widht, height)];
        imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%d",i + 1]];
        [self.view addSubview:imageView];
        
        if (i <= 3) {//当I小于等于3的时候(小于或等于第4张图片的时候)
            
            x = i * widht;//X轴第一次循环是0乘widht第二次是1乘widht.......
            y = 0;   //第一行的图片在最上方,所以Y轴没有坐标
            
        }else if(i <= 9){//9是第一行最一张往下那一列的最后一张图片
            
            //当第一行循环完毕 开始玩下走得时候因为第一个判断已经计算出一列循环的坐标,所以只需要用X的总宽度减掉第一个循环中得宽度就可以得出一列每一行最后一张图片的坐标;
            x = KScreenwidh - widht;
            y = (i - 3) *height;//当I开始是计算一列每一行最后一张图片的坐标时,I在此时走完第一个判断I等于4,所以用I减掉3再乘Y轴的总高度就可以算出Y一列每一行最后一张图片的坐标
            
        }else if(i <= 12){
            
            //每一张图片的坐标是左上角开始
            x = KScreenwidh - (i - 8) * widht;
            y = KScreenheight - height;
        
        }else if (i <= 17){
        
            x = 0;
            y = KScreenheight - (i - 11) * height;
        
        }else if(i <= 19){
        
            x = (i - 17) * widht;
            y = height;
            
        }else if(i <= 23){
            
            x = 2 * widht;//每一行第三张图片的坐标
            y = (i - 18) * height;
        
        }else if (i <= 27){
        
            x = widht;
            y = KScreenheight - (i - 22) * height;//i从23开始,所以倒数第二行第二张图片的坐标就是I 减 22每判断一次I就加1,Y坐标的图片就加1
        
        }
//        imageView.layer.cornerRadius = 4;
//        imageView.layer.borderWidth = 2;
//        imageView.layer.borderColor = [UIColor greenColor].CGColor;
        imageView.origin = CGPointMake(x, y);//给坐标赋值
        imageView. alpha = 0; //修改图片的透明度
        [_imageArr addObject:imageView];
        
        
        
    }




}



@end

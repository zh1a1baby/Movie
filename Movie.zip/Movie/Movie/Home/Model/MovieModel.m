//
//  MovieModel.m
//  Movie
//
//  Created by mac on 16/4/19.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MovieModel.h"

@implementation MovieModel






@end

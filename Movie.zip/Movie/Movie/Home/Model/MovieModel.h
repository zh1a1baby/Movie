//
//  MovieModel.h
//  Movie
//
//  Created by mac on 16/4/19.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovieModel : NSObject


#pragma  mark -- 传导数据方法
@property(strong,nonatomic)NSDictionary *rating;//评分
@property(strong,nonatomic)NSArray *genres;//类型
@property(copy,nonatomic)NSString *title;//头名
@property(assign,nonatomic)NSUInteger collect_count;//收藏数
@property(copy,nonatomic)NSString *original_title;//曾用名
@property(copy,nonatomic)NSString *year;//年份
@property(strong,nonatomic)NSDictionary *images;//图片



/*
 
 {
 "count": 20,
 "start": 0,
 "total": 23,
 "subjects": [
 {
 "rating": {
 "max": 10,
 "average": 8,
 "stars": "40",
 "min": 0
 },
 "genres": [
 "剧情",
 "奇幻",
 "冒险"
 ],
 "title": "奇幻森林",
 "collect_count": 35801,
 "original_title": "The Jungle Book",
 "subtype": "movie",
 "directors": [
 "year": "2016",
 "images": {
 "small": "http://img3.doubanio.com/view/movie_poster_cover/ipst/public/p2324130709.jpg",
 "large": "http://img3.doubanio.com/view/movie_poster_cover/lpst/public/p2324130709.jpg",
 "medium": "http://img3.doubanio.com/view/movie_poster_cover/spst/public/p2324130709.jpg"
 },
 "alt": "https://movie.douban.com/subject/25777636/",
 "id": "25777636"
 },
 */



@end

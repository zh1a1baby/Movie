//
//  HomeViewController.m
//  Movie
//
//  Created by mac on 16/4/18.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "HomeViewController.h"
#import "MovieModel.h"
#import "JSONData.h"
#import "MovieTableViewCell.h"
#import "PostView.h"
#define CellID @"MyCellId"

@interface HomeViewController ()<UITableViewDataSource,UITableViewDelegate>{


    UIView *_viewOverturn;
    UIButton *_button;
    UIButton *_button1;
    PostView *_viewItem;
    UITableView *_viewItem1;
    NSMutableArray *_movieData;
}

@end

@implementation HomeViewController
//导入实现要实现的方法
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //加载数据
    [self _JSONDataTransmission];
    //首页右边导航栏按钮
    [self _buttonOverturn];
    //海报视图
    [self _createTarBarButton];
    //列表视图
    [self _arrangeTarBarButton];
    
    

}

#pragma mark----加载首页数据
-(void)_JSONDataTransmission{
////1.获取bundel中的数据
//    NSString *JSONstring = [[NSBundle mainBundle]pathForResource:@"new_movie" ofType:@"json"];
//    
//    //2.将对应路径的JOSN文件转化成二进制文件
//    NSData *JSONdata = [NSData dataWithContentsOfFile:JSONstring];
//    //3.将JOSN文件转化成对象,创建一个字典存放对象.
//    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:nil];
//    NSLog(@"dic = %@",dic);
    
    NSDictionary *dic = [JSONData loadJSONData:@"new_movie"];
    
    
    NSArray *subjects = dic[@"subjects"];
    
    _movieData = [NSMutableArray array];
    
    
    for (NSDictionary *MovieDic in subjects) {
        
        MovieModel *movieModel = [[MovieModel alloc]init];
        
        movieModel.rating = MovieDic[@"rating"];//评分
        movieModel.genres = MovieDic[@"genres"];//类型
        movieModel.title = MovieDic[@"title"];//头名
        movieModel.collect_count = [MovieDic[@"collect_count"] integerValue];//收藏数
        movieModel.original_title = MovieDic[@"original_title"];//曾用名
        movieModel.year = MovieDic[@"year"];//年份
        movieModel.images = MovieDic[@"images"];//图片
        
        [_movieData addObject:movieModel];
        

    }
    
    NSLog(@"_movieData = %@",_movieData);

}

#pragma mark --- 海报视图
-(void) _createTarBarButton{
    //创建海报视图(父视图)
    _viewItem = [[PostView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KScreenheight - TabBarHeight - NavigationController)];
    //设置父视图颜色
//    _viewItem.backgroundColor = [UIColor purpleColor];
    
//    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KScreenheight - TabBarHeight - NavigationController)];
//    
//    image.image = [UIImage imageNamed:@"bg_main"];
//    
//    UIImageView *image1 = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh,TabBarHeight)];
//    image1.image = [UIImage imageNamed:@"indexBG_home"];
    
//    [self.view addSubview:image];
//    [self.view addSubview:image1];
    [self.view addSubview:_viewItem];
    //把海报视图设置为不隐藏
    _viewItem.hidden = NO;
    
    _viewItem.lagercollerView = _movieData;
    

}

#pragma mark --- 首页列表视图
-(void) _arrangeTarBarButton{


    _viewItem1 = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KScreenheight - TabBarHeight - NavigationController)];
    
    _viewItem1.dataSource = self;
    _viewItem1.delegate = self;
    
    _viewItem1.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:_viewItem1];
    
    _viewItem1.hidden = YES;
    
    //注册单元格
    [_viewItem1 registerNib:[UINib nibWithNibName:@"MovieTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:CellID];

}

#pragma mark -- 创建首页右边导航栏按钮
-(void)_buttonOverturn{
    
    
    _viewOverturn = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 50, 30)];
    UIBarButtonItem *Barbutton = [[UIBarButtonItem alloc]initWithCustomView:_viewOverturn];

    self.navigationItem.rightBarButtonItem = Barbutton;
    
    
    
    _button = [UIButton buttonWithType:UIButtonTypeCustom];
    _button.frame = CGRectMake(0, 0, 50, 30);

    [_button setBackgroundImage:[UIImage imageNamed:@"exchange_bg_home"] forState:UIControlStateNormal];
    
    [_button setImage:[UIImage imageNamed:@"poster_home"] forState:UIControlStateNormal];
    
    [_button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    _button.hidden = NO;
    [_viewOverturn addSubview:_button];
    
    
    //翻转按钮
    _button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    _button1.frame = CGRectMake(0, 0, 50, 30);
    
    [_button1 setBackgroundImage:[UIImage imageNamed:@"exchange_bg_home"] forState:UIControlStateNormal];
    
    [_button1 setImage:[UIImage imageNamed:@"list_home"] forState:UIControlStateNormal];
    
    [_button1 addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    _button1.hidden = YES;
    [_viewOverturn addSubview:_button1];
    
}

#pragma mark -- 首页导航栏按钮点击事件
-(void)buttonAction:(UIButton *)button{
    
    UIViewAnimationOptions options = _button.hidden?UIViewAnimationOptionTransitionFlipFromLeft:UIViewAnimationOptionTransitionFlipFromRight;
    
    [UIView transitionWithView:_viewOverturn duration:.5 options:options animations:^{
        _button.hidden =! _button.hidden;
        _button1.hidden =! _button1.hidden;
    } completion:^(BOOL finished) {
        
    }];
    
//    UIViewAnimationOptions options = _viewOverturn.hidden?UIViewAnimationOptionTransitionFlipFromLeft:UIViewAnimationOptionTransitionFlipFromRight;
    
    [UIView transitionWithView:self.view duration:.5 options:options animations:^{
        _viewItem.hidden =!_viewItem.hidden;
        _viewItem1.hidden =! _viewItem1.hidden;
    } completion:^(BOOL finished) {
        
    }];

    
    
}

#pragma mark -- 表示图实现方法
//单元格个数(首页)
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return _movieData.count;



}

//返回单元格(首页)
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MovieTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellID forIndexPath:indexPath];
    
    cell.cellModel = _movieData[indexPath.row];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    

    return cell;

}

//单元格高度(首页)
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{


    return 100;

}


@end

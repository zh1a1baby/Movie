//
//  PostView.h
//  Movie
//
//  Created by mac on 16/4/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PostView : UIView

@property (strong,nonatomic)NSArray *lagercollerView;

@end

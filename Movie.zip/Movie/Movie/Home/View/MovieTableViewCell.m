//
//  MovieTableViewCell.m
//  Movie
//
//  Created by mac on 16/4/19.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MovieTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "UIViewExt.h"

@implementation MovieTableViewCell

#pragma mark -- 加载数据实现方法
-(void)layoutSubviews{
    
    [super layoutSubviews];

    //电影名
    _titleLabel.text = _cellModel.title;
    //上映年份
    _yearLabel.text = [NSString stringWithFormat:@"上映年份%@",_cellModel.year];
    //评分
    _ratingLabel.text = [NSString stringWithFormat:@"评分%.1f",[_cellModel.rating[@"average"] floatValue]];
    
    NSURL *url = [NSURL URLWithString:_cellModel.images[@"medium"]];
    
    [_imgView sd_setImageWithURL:url];
    
    // 设置星星图片
//    UIImage *grayimage = [UIImage imageNamed:@"gray"];
//    UIImage*yellowimage = [UIImage imageNamed:@"yellow"];
    
//    //创建星星视图
//    UIView *grayView = [[UIView alloc]initWithFrame:CGRectMake(0, 0,grayimage.size.width*5, yellowimage.size.height)];
//    grayView.backgroundColor = [UIColor colorWithPatternImage:grayimage];
//    [_starView addSubview:grayView];
//    
//    UIView *yellowView = [[UIView alloc]initWithFrame:CGRectMake(0, 0,yellowimage.size.width * 5, yellowimage.size.height)];
//    yellowView.backgroundColor = [UIColor colorWithPatternImage:yellowimage];
//    [_starView addSubview:yellowView];
//    
//    //对星星图片进行放大
//    float scale = _starView.frame.size.height /grayView.frame.size.height;
//    
//    grayView.transform = CGAffineTransformMakeScale(scale, scale);
//    yellowView.transform = CGAffineTransformMakeScale(scale, scale);
//    
//    //将坐标放回原点
//    grayView.origin = CGPointZero;
//    yellowView.origin = CGPointZero;
//    
//    float skt = [_cellModel.rating[@"average"] floatValue];
//    
//    yellowView.width = yellowView.width*(skt / 10.00);
//    
//    
    
    
    /*
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        
        NSData *data = [NSData dataWithContentsOfURL:url];
        
        UIImage *image = [UIImage imageWithData:data];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            self.imgView.image = image;
            
        });
    });
     */
//    _imgView.image = [UIImage imageNamed:@"38e9a61ea8d3fd1f1fd00293374e251f94ca5f24.jpg"];
    
    
    _starView.staring = [_cellModel.rating[@"average"] floatValue];
    
    


}






@end

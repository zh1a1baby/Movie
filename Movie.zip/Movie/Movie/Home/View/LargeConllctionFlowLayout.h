//
//  LargeConllctionFlowLayout.h
//  Movie
//
//  Created by mac on 16/4/22.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseCollectionViewFlowLayout.h"
@interface LargeConllctionFlowLayout : BaseCollectionViewFlowLayout

@end

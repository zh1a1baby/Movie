//
//  MiddleView.h
//  Movie
//
//  Created by mac on 16/4/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseCollectionView.h"
@interface MiddleView : BaseCollectionView

//@property(strong,nonatomic)NSArray *lagerViewcoll;

@end

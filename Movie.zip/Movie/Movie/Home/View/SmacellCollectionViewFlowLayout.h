//
//  SmacellCollectionViewFlowLayout.h
//  Movie
//
//  Created by mac on 16/4/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseCollectionViewFlowLayout.h"

@interface SmacellCollectionViewFlowLayout : BaseCollectionViewFlowLayout

@end

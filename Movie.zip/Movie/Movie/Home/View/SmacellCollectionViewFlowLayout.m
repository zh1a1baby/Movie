//
//  SmacellCollectionViewFlowLayout.m
//  Movie
//
//  Created by mac on 16/4/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "SmacellCollectionViewFlowLayout.h"

@implementation SmacellCollectionViewFlowLayout

-(instancetype)init{
    
    self = [super init];
    
    if (self != nil) {
        
        //单元格大小
        self.itemSize =CGSizeMake(80, KmoviewHeaderViewoffset);
        
    }
    
    
    
    return self;

}
@end

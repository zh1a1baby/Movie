//
//  PostView.m
//  Movie
//
//  Created by mac on 16/4/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "PostView.h"
#import "MiddleView.h"
#import "LargeConllctionFlowLayout.h"
#import "BaseCollectionView.h"
#import "SmacellCollectionViewFlowLayout.h"
#import "Smallcell.h"
#import "samllCollectionView.h"

@interface PostView (){


    //传递大集合视图的数据
    MiddleView *_lagercolltionView;
    //传递小集合视图的数据
    samllCollectionView*_mallView;
    //电影下边的文字标题
    UILabel *_moviewtitleLabel;
    
    UIImageView *_imageView;
    UIButton *_button;
    UIControl *_maskview;

    
}


@end

@implementation PostView

#pragma mark --- 移除观察者
-(void)dealloc{

    [_lagercolltionView removeObserver:self forKeyPath:@"crrentPath"];
    
    [_mallView removeObserver:self forKeyPath:@"crrentPath"];
    

}

#pragma mark --- 方法的调用
-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    
    
    if(self){
    
        //集合视图
        [self _createCollertioncell];
        // 设置遮罩视图
//        [self _createmaskview];
        //头部视图
        [self _createCollerView];
        // 手势滑动方向
        [self _createGesture];
        //小集合视图
        [self _createSmallCollectionView];
        
        //电影图片的影名
        [self _filmScript];
        
        
        
        //大集合视图海报观察者
        [_lagercolltionView addObserver:self forKeyPath:@"crrentPath" options:NSKeyValueObservingOptionNew context:nil];
        
        //小集合视图海报观察者
        [_mallView addObserver:self forKeyPath:@"crrentPath" options:NSKeyValueObservingOptionNew context:nil];
        
        

    }


    return self;


}

#pragma mark --- 当观察者观察到大海报和小海报的值发生变化的时候会调用这个方法
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context{
    //获取最新的属性变化之后的值
    NSInteger index = [change [@"new"] integerValue];
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:index inSection:0];
    //把从数据库中调用出来的名字移到观察者当中,每当滑动图片的时候就会调用这里面的方法就可以刷新电影名字的数据,
    //给第一样的电影图片一个名称
    MovieModel *modelLabel = _lagercollerView[index];
    //调用数据库中的名字给_moviewtitleLabel,title是调用了数据库的电影名
    _moviewtitleLabel.text = modelLabel.title;

    
    if([object isKindOfClass:[MiddleView class]]&& _mallView.crrentPath != index){
        //让小海报视图跟着一起动
        
    
        [_mallView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        //手动更新最新页数的数值
        _mallView.crrentPath = index;
    
    }
    else if([object isKindOfClass:[samllCollectionView class]]&&_lagercolltionView.crrentPath != index){
    
        //让大海报视图跟着一起动
        [_lagercolltionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        //手动更新最新页数的数值
        _lagercolltionView.crrentPath = index;
    
    }
    
    
    
}



#pragma makr ---集合视图
-(void)_createCollertioncell{

    //创建布局对象
    LargeConllctionFlowLayout *flowView = [[LargeConllctionFlowLayout alloc]init];
    //设置单元格大小
    flowView.itemSize = CGSizeMake(KScreenwidh * 0.7, KScreenheight - NavigationController - TabBarHeight - KmoviewHeaderViewHeight - KmoviewfootViewHeight);
    //设置单元格滑动模式(平铺)
    flowView.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    
    //创建集合视图
    CGRect llecview = CGRectMake(0, 50, KScreenwidh, KScreenheight - TabBarHeight - NavigationController -KmoviewfootViewHeight-KmoviewHeaderViewHeight + 50);
    
    _lagercolltionView = [[MiddleView alloc]initWithFrame:llecview collectionViewLayout:flowView];
    
    _lagercolltionView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    
    [self addSubview:_lagercolltionView];
    
    
}

#pragma mark --- 创建头视图
-(void)_createCollerView{
    //头视图创建
    _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, -KmoviewHeaderViewoffset, KScreenwidh, KmoviewHeaderViewHeight)];
    //拉伸头视图图片
    UIImage *image = [UIImage imageNamed:@"indexBG_home"];
    UIImage *newimage = [image stretchableImageWithLeftCapWidth:0 topCapHeight:4];
    //将拉伸的新的图片给imageView
    _imageView.image = newimage;
    //用户交互允许点击
    _imageView.userInteractionEnabled = YES;
    
    [self addSubview:_imageView];
    
    
    _button = [UIButton buttonWithType:UIButtonTypeCustom];
    
    _button.frame = CGRectMake((KScreenwidh - 20)/2, KmoviewHeaderViewHeight - 20, 20, 20);
    [_button setBackgroundImage:[UIImage imageNamed:@"down_home"] forState:UIControlStateNormal];
    //UIControlStateSelected当被点击时
    [_button setBackgroundImage:[UIImage imageNamed:@"up_home"] forState:UIControlStateSelected];
    
    [_button addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [_imageView addSubview:_button];
    
    
}

#pragma mark ---头部视图点击事件
-(void)buttonAction:(UIButton *)button{

//    button.selected = !button.selected;
    
    
    
    if(button.selected){//当头视图被选中的时候
        
        [self _hideheaderView]; //头视图隐藏
        
        
//        _imageView.frame = CGRectMake(0, 0, KScreenwidh, KmoviewHeaderViewHeight);
//        _imageView.transform = CGAffineTransformTranslate(_imageView.transform, 0, KmoviewHeaderViewoffset);
    }else{//当头视图未被选中的时候
    
//        _imageView.frame = CGRectMake(0, -KmoviewHeaderViewoffset, KScreenwidh, KmoviewHeaderViewHeight);
//        _imageView.transform = CGAffineTransformIdentity;
        
        [self _showHeaderView];//头视图显示
    
    }
}


#pragma mark --- 小的集合视图
-(void)_createSmallCollectionView{
    //创建布局对象
    SmacellCollectionViewFlowLayout *collectionFlowLayout = [[SmacellCollectionViewFlowLayout alloc]init];
    //多余的代码{
    //    collectionFlowLayout.itemSize = CGSizeMake(80, KmoviewHeaderViewoffset);
    //    collectionFlowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    //}
    
    //创建集合视图
    _mallView = [[samllCollectionView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KmoviewHeaderViewoffset) collectionViewLayout:collectionFlowLayout];
    
    [_imageView addSubview:_mallView];
    
    
    
}

#pragma mark--- 设置滑动手势滑动方向
-(void)_createGesture{
    //创建滑动方法
    UISwipeGestureRecognizer *gesture = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(_showHeaderView)];
    //滑动手势的方向
    gesture.direction = UISwipeGestureRecognizerDirectionDown;
    [self addGestureRecognizer:gesture];
    



}

#pragma mark --- 头视图下拉
-(void)_showHeaderView{
    _button.selected = YES;
    _maskview.hidden = NO;
    //显示头部视图
    
    
    [UIView animateWithDuration:0.2 animations:^{
        //修改头视图下拉
        _imageView.transform = CGAffineTransformMakeTranslation(0, KmoviewHeaderViewoffset);
        
    }];
    
    
    
}

#pragma makr --- 头视图复原
-(void)_hideheaderView{
    _button.selected = NO;
    
    _maskview.hidden = YES;
    [UIView animateWithDuration:0.2 animations:^{
        //修改头视图复原
        _imageView.transform = CGAffineTransformIdentity;

    }];

    //隐藏头部视图



}


-(void)_filmScript{

    _moviewtitleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, KScreenheight - TabBarHeight - NavigationController - 50,KScreenwidh, 40)];
//    _moviewtitleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, KScreenheight - TabBarHeight - 150,KScreenwidh, 40)];


    //居中
    _moviewtitleLabel.textAlignment = NSTextAlignmentCenter;
    //文字的大小
    _moviewtitleLabel.font = [UIFont systemFontOfSize:20];
    //文字的颜色
    _moviewtitleLabel.textColor = [UIColor orangeColor];
    
    [self addSubview:_moviewtitleLabel];



}


#pragma mark --- 集合视图数据传输
-(void)setLagercollerView:(NSArray *)lagercollerView{
    
    _lagercollerView = lagercollerView;
    //数据传给大的集合视图
    _lagercolltionView.lagerViewcoll = _lagercollerView;
    //数据传给小的集合视图
    _mallView.lagerViewcoll = _lagercollerView;
    //给第一样的电影图片一个名称
    MovieModel *modelLabel = _lagercollerView[0];
    //调用数据库中的名字给_moviewtitleLabel,title是调用了数据库的电影名
    _moviewtitleLabel.text = modelLabel.title;
    
}




//#pragma mark --- 设置头视图灰度视图
//-(void)_createmaskview{
//    //设置灰度
//    _maskview = [[UIControl alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KScreenheight - TabBarHeight - NavigationController)];
//    //设置灰度
//    _maskview.backgroundColor = [UIColor colorWithWhite:.3 alpha:0.5];
//
//    _maskview.hidden = YES;
//
//    [_maskview addTarget:self action:@selector(_hideheaderView) forControlEvents:UIControlEventTouchUpInside];
//
//    [self addSubview:_maskview];
//
//}

@end

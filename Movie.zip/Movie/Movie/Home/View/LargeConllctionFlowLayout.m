//
//  LargeConllctionFlowLayout.m
//  Movie
//
//  Created by mac on 16/4/22.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "LargeConllctionFlowLayout.h"

@implementation LargeConllctionFlowLayout

-(instancetype)init{

    self = [super init];
    
    
    if (self != nil) {
        self.itemSize = CGSizeMake(KScreenwidh * 0.7, KScreenheight - NavigationController - TabBarHeight - KmoviewHeaderViewHeight - KmoviewfootViewHeight);
        //设置单元格滑动模式(平铺)
        self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        

    }

    return self;


}

//图片放大缩小

-(BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds{


    return YES;

}

-(NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect{
    
    //获取当前collectionView可见的区域和坐标
    CGRect visibleRect;
    
    visibleRect.origin = self.collectionView.contentOffset;
    visibleRect.size = self.collectionView.bounds.size;
    
    //调用父类的方法,获取当前rect中这些item的布局属性(显示当前区域item的属性)
    NSArray *attributes = [super layoutAttributesForElementsInRect:rect];
    //保证数组中数据的安全
    NSArray *safeAttributes = [[NSArray alloc]initWithArray:attributes copyItems:YES];
    
    for (UICollectionViewLayoutAttributes *Attributes in safeAttributes) {
        
        
        //判断属性是否在item的是否有交集(item是否进入系统检测范围内)
        if (CGRectIntersectsRect(Attributes.frame, rect)) {
            
            //获取距离
            float distance = CGRectGetMidX(visibleRect)-Attributes.center.x;
            //距离缩小图片放大
            float discble = distance /200;
            
            if (ABS(distance)<200) {
                //对空间3个方向进行放大
                float scale = 1+0.1*(1- ABS(discble));
                
                Attributes.transform3D = CATransform3DMakeScale(scale, scale, 1);
                Attributes.zIndex = 1;
                
                
            }
            
            
        }
        
        
    }
    


    return safeAttributes;

}

@end

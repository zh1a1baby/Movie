//
//  samllCollectionView.h
//  Movie
//
//  Created by mac on 16/4/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseCollectionView.h"

@interface samllCollectionView : BaseCollectionView
//@property (strong,nonatomic)NSArray *smallModel;
@end

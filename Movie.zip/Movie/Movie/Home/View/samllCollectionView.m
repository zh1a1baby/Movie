//
//  samllCollectionView.m
//  Movie
//
//  Created by mac on 16/4/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "samllCollectionView.h"
#import "Smallcell.h"
#define cellID @"samllCellID"

@implementation samllCollectionView

-(instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout{

    self = [super initWithFrame:frame collectionViewLayout:layout];
    
    if(self != nil){
    
        //注册单元格
        [self registerClass:[Smallcell class] forCellWithReuseIdentifier:cellID];
    
    }
    
    return self;

}
//item
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    Smallcell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID forIndexPath:indexPath];
    
    
    cell.samllView = self.lagerViewcoll[indexPath.item];
    
    
    return cell;
    
    
}
//设置边缘距离
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{

    return UIEdgeInsetsMake(0, (KScreenwidh - 80)/2, 0, (KScreenwidh - 80)/2);

}


@end

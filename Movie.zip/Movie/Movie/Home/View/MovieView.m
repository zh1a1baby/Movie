//
//  MovieView.m
//  Movie
//
//  Created by mac on 16/4/22.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MovieView.h"
#import "UIImageView+WebCache.h"

@implementation MovieView


-(void)setMoviewmodel:(MovieModel *)moviewmodel{
    
    _moviewmodel = moviewmodel;
    //电影名
    _titleLabel.text = _moviewmodel.title;
    //上映年份
    _yearLabel.text = [NSString stringWithFormat:@"上映年份%@",_moviewmodel.year];
    //评分
    _ratingLabel.text = [NSString stringWithFormat:@"评分%.1f",[_moviewmodel.rating[@"average"] floatValue]];
    
    NSURL *url = [NSURL URLWithString:_moviewmodel.images[@"large"]];
    
    [_imgView sd_setImageWithURL:url];
    
    _starView.staring = [_moviewmodel.rating[@"average"] floatValue];



}

@end

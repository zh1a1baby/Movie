//
//  MiddleView.m
//  Movie
//
//  Created by mac on 16/4/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MiddleView.h"
#import "MiddleCollectionViewCell.h"
#import "MovieModel.h"
#import "LargeConllctionFlowLayout.h"
#import "BaseCollectionView.h"
#define CellID @"MycellID"

@interface MiddleView ()
//<UICollectionViewDelegateFlowLayout,UICollectionViewDataSource>

@end

@implementation MiddleView

//复写init方法判断self等于nil的时候设置代理
-(instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout{

    self = [super initWithFrame:frame collectionViewLayout:layout];
    
    //判断,当self(本身对象)等于空的时候就设置一个代理,并注册单元格
    if(self){
    
        
//        self.dataSource = self;
//        self.delegate = self;
//        self.decelerationRate = UIScrollViewDecelerationRateFast;
//        self.showsHorizontalScrollIndicator = NO;
    
        [self registerClass:[MiddleCollectionViewCell class] forCellWithReuseIdentifier:CellID];

    
    }

    return self;
}

//单元格个数
//- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
//
//    return _lagerViewcoll.count;
//
//}
//
//返回单元格中的值
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    MiddleCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CellID forIndexPath:indexPath];
    
    cell.modelView = self.lagerViewcoll[indexPath.item];
    
    
    return cell;
    

}
//设置单元格边缘
-(UIEdgeInsets )collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{

    //设置边缘距离(上下左右)
    return UIEdgeInsetsMake(10, (KScreenwidh - KScreenwidh *.7)/2, 10, (KScreenwidh - KScreenwidh *.7)/2);
    

}
//点击图片的触发点击事件
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if(self.crrentPath != indexPath.item){//当前视图不等于点击的视图
        self.userInteractionEnabled = NO;
        
        [self scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            self.userInteractionEnabled = YES;

        });
        
        
        
        self.crrentPath = indexPath.item;
    
        
    }else{
        //点击哪个单元格,对应的单元格要翻转
        MiddleCollectionViewCell *selectedCell = (MiddleCollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
        //点击的单元格进行翻转
        [selectedCell cellFlip];
        

    
    }
    
    
    
}
//重置点击图片的翻转时间
- (void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    //强制转换重置cell的翻转状态
    MiddleCollectionViewCell *selectedCell = (MiddleCollectionViewCell *)cell;
    //重置 cell 的翻转状态
    [selectedCell resetcell];
}

//
//-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset{
//    //X轴的滑动位置
//    float xoffset = targetContentOffset->x;
//    //获取当前的活动对象
//    LargeConllctionFlowLayout *flowLayouw =(LargeConllctionFlowLayout *)self.collectionViewLayout;
//    //获取宽
//    NSInteger pagWidht = KScreenwidh *0.7 + flowLayouw.minimumLineSpacing;
//    //获取当前的页数
//    NSInteger pagnuw = (pagWidht/2 +xoffset)/pagWidht;
//    //只想中间的位置
//    targetContentOffset->x = pagnuw *pagWidht;
//    
//    pagnuw = velocity.x == 0?pagnuw:(velocity.x > 0)?pagnuw+1:pagnuw - 1;
//    
//    self.crrentPath = pagnuw;
//}




@end

//
//  MovieTableViewCell.h
//  Movie
//
//  Created by mac on 16/4/19.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MovieModel.h"
#import "starView.h"
@interface MovieTableViewCell : UITableViewCell

#pragma mark -- 接收数据方法
@property (strong,nonatomic)MovieModel *cellModel;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *yearLabel;
@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet starView *starView;


@end

//
//  Smallcell.h
//  Movie
//
//  Created by mac on 16/4/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MovieModel.h"
@interface Smallcell : UICollectionViewCell
//获取MoviewModel 类中的值
@property(strong , nonatomic)MovieModel *samllView;


@end

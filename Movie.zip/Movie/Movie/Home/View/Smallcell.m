//
//  Smallcell.m
//  Movie
//
//  Created by mac on 16/4/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "Smallcell.h"
#import "UIImageView+WebCache.h"


@interface Smallcell (){
    UIImageView *_smallimagView;
    
}

@end
@implementation Smallcell

-(instancetype)initWithFrame:(CGRect)frame{
    
    self = [super initWithFrame:frame];
    
    if (self != nil) {
        
        //设置单元格图片全屏
        _smallimagView = [[UIImageView alloc]initWithFrame:self.bounds];
        
        [self.contentView addSubview:_smallimagView];
        
    }
    return self;
}

-(void)setSamllView:(MovieModel *)samllView{
    //接收传过来的值
    _samllView = samllView;
    //获取网络数据
    NSURL *url =[NSURL URLWithString:_samllView.images[@"small"]];
    
    [_smallimagView sd_setImageWithURL:url];
    
    
    
}


@end

//
//  AppDelegate.m
//  Movie
//
//  Created by mac on 16/4/18.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "AppDelegate.h"
#import "BaseTabBarController.h"
#import "PromoterViewController.h"
#import "LastViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //延迟调用
//    sleep(1);
    
    //创建根视图
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [UIColor blackColor];
    [self.window makeKeyAndVisible];
    
    
    //取得版本的信息
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    //通过打印获取版本当中的信息
//    NSLog(@"infoDic = %@",infoDic);
    
    //将版本信息存入浮点型的对象当中
    double version = [infoDic [@"CFBundleShortVersionString"] doubleValue];
    //通过打印知道版本的信息有没有存入浮点型的对象当中
//    NSLog(@"version = %.1f",version);
    
    // 类方法,取得lnfo.plist文件中得偏好设置`
    NSUserDefaults *userdefaults = [NSUserDefaults standardUserDefaults];
    
    //此方法相当于会更新版本的信息,如果之前没有存储过版本的信息的话,那么此方法里面存储的就会是0;
    double lastVersion = [[userdefaults objectForKey:@"version"] doubleValue];
    
    
    if(version > lastVersion){
        
        //当当前的版本信息比之前的版本信息要大时
        //就引导之前的版本信息在此方法中更新成最新的版本信息
        self.window.rootViewController = [[PromoterViewController alloc]init];
        //更新沙盒路径中得版本信息
        [userdefaults setObject:@(version) forKey:@"version"];
        
    }else{
        
        //当当前的版本信息和之前的版本信息相匹配的时候就会直接进入APP当中的内容界面
        self.window.rootViewController = [[LastViewController alloc]init];
    
    }
    
    
    
    
    
    return YES;
}

@end

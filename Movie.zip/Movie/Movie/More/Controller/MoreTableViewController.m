//
//  MoreTableViewController.m
//  Movie
//
//  Created by mac on 16/4/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MoreTableViewController.h"
#import "SDImageCache.h"
@interface MoreTableViewController ()<UIAlertViewDelegate>

@end

@implementation MoreTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    //当单元格等于0的时候点击单元格会创建一个提示框(是否清除缓存)
    if(indexPath.row == 0 ){
        //提示框的创建
        UIAlertView *alertView = [[UIAlertView alloc]initWithTitle:@"清理缓存" message:@"哈哈" delegate:self cancelButtonTitle:@"不清理" otherButtonTitles:@"清理", nil];
        //在视图上显示提示框
        [alertView show];
    }
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(buttonIndex == 1){
    
        [[SDImageCache sharedImageCache] clearDisk];// 清除沙盒路径的缓存
        [[SDImageCache sharedImageCache] clearMemory];//清楚系统运行中的缓存
        
        //当缓存被清楚之后刷新数据
        [self.tableView reloadData];

    }

}
//即将进视图的时候刷新数据
- (void)viewWillAppear:(BOOL)animated{

    [self.tableView reloadData];

}


-(void)tableView:(UITableView *)tableView willDisplayCell:(nonnull UITableViewCell *)cell forRowAtIndexPath:(nonnull NSIndexPath *)indexPath{

    if(indexPath.row == 0){
        //创建一个label计算缓存中的数据
        UILabel *cacheLabel = [cell.contentView viewWithTag:1024];
        //计算内存中缓存了多少的数据size = %ld B < %ld kb < %ld MB
        NSUInteger size = [[SDImageCache sharedImageCache] getSize];
        NSLog(@"size = %ld",size);
        //获取size的缓存数据之后(%ld B)除以1024得出有多少KB在除以1024得出有多少MB
        cacheLabel.text = [NSString stringWithFormat:@"%.1f MB",size/1024/1024.0];
        
    }




}

@end

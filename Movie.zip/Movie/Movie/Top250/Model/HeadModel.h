//
//  HeadModel.h
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HeadModel : NSObject

@property (copy ,nonatomic)NSString *image;//电影海报图片
@property (copy ,nonatomic)NSString *titleCn;//影片名字
@property (copy ,nonatomic)NSString *rating;//评分
@property (strong ,nonatomic)NSArray *directors;//导演名字
@property (strong ,nonatomic)NSArray *actors;//演员
@property (strong ,nonatomic)NSDictionary *detailRelease;//地点时间
@property (strong ,nonatomic)NSArray *images;//




/*"image" : "http://img31.mtime.cn/mt/2012/06/28/131128.94272291.jpg",
	"titleCn" : "摩尔庄园2海妖宝藏",
	"rating" : "7.7",
	"url" : "http://movie.mtime.com/157836/",
	"directors" : [ "刘可欣" ],
	"actors" : ["阿黄","阿龟","阿宇","阿红","凤姐"],
	"release" : {
 "location" : "中国",
 "date" : "2012-7-5"
 "images" : [ "http://img31.mtime.cn/pi/2012/06/14/193026.85486289.jpg",
 "http://img31.mtime.cn/pi/2012/06/14/193028.65049217.jpg",
 "http://img31.mtime.cn/pi/2012/06/14/193029.38103098.jpg",
 "http://img31.mtime.cn/pi/2012/06/14/193030.29253345.jpg" ],*/
@end

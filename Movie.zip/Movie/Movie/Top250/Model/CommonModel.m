//
//  CommonModel.m
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "CommonModel.h"

@implementation CommonModel

@end

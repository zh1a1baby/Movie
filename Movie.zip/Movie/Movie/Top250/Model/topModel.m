//
//  topModel.m
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "topModel.h"

@implementation topModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{



}



@end

//
//  HeadModel.m
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "HeadModel.h"

@implementation HeadModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{

    if([key isEqualToString:@"release"]){
        
        _detailRelease = value;
        
    }



}




@end

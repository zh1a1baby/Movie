//
//  CommonView.h
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseViewController.h"
@interface CommonView : BaseViewController




@end

//
//  TopViewController.m
//  Movie
//
//  Created by mac on 16/4/18.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "TopViewController.h"
#import "JSONData.h"
#import "topModel.h"
#import "TopCollectionViewCell.h"
#import "CommonView.h"

#define TopCellID @"TopCellID"


@interface TopViewController ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>{


    NSMutableArray *_modelArrData;


}




@end

@implementation TopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    //加载数据
    [self _loadData];
    //创建集合视图
    [self _createCollectionView];

}
#pragma mark --- 加载集合视图数据
-(void)_loadData{
    
    //解析 JSON
    NSDictionary *dicData = [JSONData loadJSONData:@"top250"];
    //数组获取数据
    NSArray *arrData = dicData[@"subjects"];
    //全局的可变数据接收数据
    _modelArrData = [NSMutableArray array];
    
    //forin循环遍历字典中的数据
    for (NSDictionary *dic in arrData) {
        
        
        topModel *model = [[topModel alloc]init];
        
        [model setValuesForKeysWithDictionary:dic];
        
        [_modelArrData addObject:model];
        
    }

}

#pragma mark --- 创建集合视图
-(void)_createCollectionView{

//    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    
    
    
    //创建布局对象
    UICollectionViewFlowLayout *topFlowLayout = [[UICollectionViewFlowLayout alloc]init];
    
    float widh = (KScreenwidh -10 * 4) / 3;
    
    topFlowLayout.itemSize = CGSizeMake(widh, widh +50);
    
    
    
    
    //创建集合视图
    UICollectionView *topCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KScreenheight - NavigationController - TabBarHeight) collectionViewLayout:topFlowLayout];
    [topCollectionView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]]];
    
    [self.view addSubview:topCollectionView];
    //设置代理
    topCollectionView.dataSource = self;
    topCollectionView.delegate = self;
    
    // 注册单元格
    [topCollectionView registerClass:[TopCollectionViewCell class] forCellWithReuseIdentifier:TopCellID];
    


}

#pragma mark --- 集合视图的代理实现方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{


    return _modelArrData.count;


}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    TopCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:TopCellID forIndexPath:indexPath];
    
    cell.topmodel = _modelArrData[indexPath.item];
    

    return cell;

}

#pragma mark --- 集合视图上下左右的间距
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{




    return UIEdgeInsetsMake(10, 10, 10, 10);


}


#pragma mark ---当点击任意单元格时会Push到另一个界面
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{

    CommonView *commonCell = [[CommonView alloc]init];
    
    [self.navigationController pushViewController:commonCell animated:YES];



}


@end

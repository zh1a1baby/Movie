//
//  CommonView.m
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "CommonView.h"
#import "CommonModel.h"
#import "JSONData.h"
#import "CommontTableViewCell.h"
#import "HeadView.h"
#import "HeadModel.h"
#define CommontCellID @"CommontCellID"

@interface CommonView ()<UITableViewDataSource,UITableViewDelegate>{

    NSMutableArray *_commonCellArr;//接收JSON解析过的数据的可变数组
    UITableView *_commontTableView;//创建表示图
    NSIndexPath *_selectedIndexPath;//保存点击过的单元格
    HeadModel *_datamodel;

}

@end

@implementation CommonView

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //加载数据
    [self _loadData];
    //创建表示图
    [self _createCommontTableView];
    //toushitu
    [self _createHeadView];
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];


}

#pragma mark --- 加载Push过去视图的数据
-(void)_loadData{
    //解析JSON数据
    NSDictionary *dic = [JSONData loadJSONData:@"movie_comment"];
    //获取数据内容
    NSArray *list = dic[@"list"];
    //定义可变数组用于接收数组中的内容
    _commonCellArr = [NSMutableArray array];
    
    for (NSDictionary *commonDic in list) {
        //创建model对象
        CommonModel *model = [[CommonModel alloc]init];
        //对model对象依次赋值取得JSON中的数据
        [model setValuesForKeysWithDictionary:commonDic];
        //将model对象中的值存入可变数组中
        [_commonCellArr addObject:model];
    }
    
    //解析头视图
    NSDictionary *headDic = [JSONData loadJSONData:@"movie_detail"];
    _datamodel = [[HeadModel alloc]init];
    [_datamodel setValuesForKeysWithDictionary:headDic];

}

#pragma mark --- 创建表示图
-(void)_createCommontTableView{
    
       //表示图大小的坐标
    CGRect rect = CGRectMake(0, 0, KScreenwidh, KScreenheight - NavigationController - TabBarHeight);
    //UITableViewStylePlain平铺 ,创建表示图
    _commontTableView = [[UITableView alloc]initWithFrame:rect style:UITableViewStylePlain];
    _commontTableView.backgroundColor = [UIColor clearColor];
    
    [self.view addSubview:_commontTableView];
    
    //设置代理
    _commontTableView.dataSource = self;
    _commontTableView.delegate = self;
    
    //注册代理
    [_commontTableView registerNib:[UINib nibWithNibName:@"CommontTableViewCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:CommontCellID];
    
    

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{


    return _commonCellArr.count;
    
}

#pragma mark --- 代理的方法实现
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    CommontTableViewCell *Cell = [tableView dequeueReusableCellWithIdentifier:CommontCellID forIndexPath:indexPath];

    Cell.commonmodel = _commonCellArr[indexPath.row];

    return Cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    //保存刷新的单元格的位置
    _selectedIndexPath = indexPath;
    //点击那个单元格就刷新那个单元格
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];


}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    CommonModel *model = _commonCellArr[indexPath.row];
    CGRect rect = [model.content boundingRectWithSize:CGSizeMake(280, 999) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{
                                                                                                                                      
                                                                                                                                      NSFontAttributeName:[UIFont systemFontOfSize:14]
                                                                                                                                      
                                                                                                                                      
                                                                                                                                      } context:nil];
    if(indexPath == _selectedIndexPath){
        if(rect.size.height +70 <= 120){
        
            return 120;
        
        }
        
        return rect.size.height + 120;
    
    }
    
    
    
    
    return 120;
}

#pragma mark ---头视图
-(void)_createHeadView{
    //获取xib里面所画的头视图
    
    HeadView *headview = [[[NSBundle mainBundle]loadNibNamed:@"HeadView" owner:self options:nil] firstObject];
    // 对象不能点对象,在接收数据的View里面定义model属性然后再定义model对象赋值个属性model
    headview.datamodel = _datamodel;
    [_commontTableView setTableHeaderView:headview];
//    [_commontTableView addSubview:headview];

}



@end

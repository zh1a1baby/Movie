//
//  HeadView.h
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HeadModel.h"
@interface HeadView : UIView
@property (weak, nonatomic) IBOutlet UIImageView *headimages;//电影海报图片
@property (weak, nonatomic) IBOutlet UILabel *headLabel;//影片名
@property (weak, nonatomic) IBOutlet UILabel *directorsLabel;//导演
@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;//评分
@property (weak, nonatomic) IBOutlet UILabel *actorsLabel;//演员名字
@property (weak, nonatomic) IBOutlet UILabel *locusLabel;//地点时间

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;//滑动视图
//传递数据,实现视屏播放的方法
@property (strong, nonatomic)HeadModel *datamodel;

@end

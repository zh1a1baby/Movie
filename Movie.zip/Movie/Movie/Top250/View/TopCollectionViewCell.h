//
//  TopCollectionViewCell.h
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "topModel.h"
@interface TopCollectionViewCell : UICollectionViewCell

@property (strong, nonatomic)topModel *topmodel;

@end

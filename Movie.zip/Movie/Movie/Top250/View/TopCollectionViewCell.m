//
//  TopCollectionViewCell.m
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "TopCollectionViewCell.h"
#import "starView.h"
#import "UIImageView+WebCache.h"
@interface TopCollectionViewCell (){

    UIImageView *_topimageView;//图片
    UILabel *_topLabel;//标题
    UILabel *_ratingLabel;//评分
    starView *_topStarView;//星星视图
    
}

@end

@implementation TopCollectionViewCell

-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    
    if(self != nil){
        
        [self _createSubjectsView];
    
    
    }
    return self;
}

-(void)_createSubjectsView{

    //图片坐标
    _topimageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.width,self.width +20)];
    [self.contentView addSubview:_topimageView];
    
    //标题坐标
    _topLabel = [[UILabel alloc]initWithFrame:CGRectMake(0,self.height - 35, self.width, 20)];
    //居中
    _topLabel.textAlignment = NSTextAlignmentCenter;
    //字体大小
    _topLabel.font = [UIFont systemFontOfSize:14];
    //字体颜色
    _topLabel.textColor = [UIColor purpleColor];
    _topLabel.backgroundColor = [UIColor colorWithWhite:.3 alpha:.5];
    [_topimageView addSubview:_topLabel];
    
    //星星视图
    _topStarView = [[starView alloc]initWithFrame:CGRectMake(0,self.height-17, self.width, 17)];
    _topStarView.backgroundColor = [UIColor clearColor];
    
    [_topimageView addSubview:_topStarView];
    
    //评分
    _ratingLabel = [[UILabel alloc]initWithFrame:CGRectMake(self.width - 22, 0, 25, 17)];
    _ratingLabel.textColor = [UIColor whiteColor];
    _ratingLabel.font = [UIFont systemFontOfSize:15];
    
    [_topStarView addSubview:_ratingLabel];

}

-(void)setTopmodel:(topModel *)topmodel{

    _topmodel = topmodel;
    //加载图片数据
    NSURL *url = [NSURL URLWithString:_topmodel.images[@"medium"]];

    [_topimageView sd_setImageWithURL:url];

    //加载标题数据
    _topLabel.text = _topmodel.title;
    
    //加载评分
    _ratingLabel.text = [NSString stringWithFormat:@"%.1f",[_topmodel.rating[@"average"] floatValue]];
    
    _topStarView.staring =[_topmodel.rating[@"average"] floatValue];


}


@end

//
//  HeadView.m
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "HeadView.h"
#import "UIImageView+WebCache.h"
#import "BaseNavigationController.h"
#import <MediaPlayer/MediaPlayer.h>
@implementation HeadView


-(void)setDatamodel:(HeadModel *)datamodel{
    _datamodel = datamodel;
    
    //获取数据库中的图片
    [_headimages sd_setImageWithURL:[NSURL URLWithString:_datamodel.image]];
    
    //影名
    _headLabel.text = _datamodel.titleCn;
    
    //导演
    _directorsLabel.text = _datamodel.directors[0];
    
    //评分
    _ratingLabel.text = [NSString stringWithFormat:@"评分:%@",_datamodel.rating];
    
    //演员名
    _actorsLabel.text = [NSString stringWithFormat:@"%@ %@ %@ %@",_datamodel.actors[0],_datamodel.actors[1],_datamodel.actors[2],_datamodel.actors[3]];
    
    //地点时间
    _locusLabel.text = [NSString stringWithFormat:@"%@ %@",_datamodel.detailRelease[@"location"],_datamodel.detailRelease[@"date"]];
    
    //滑动视图
    NSArray *images= _datamodel.images;
    float widht = _scrollView.frame.size.width/4;
    
    // 内容尺寸
    _scrollView.contentSize = CGSizeMake(widht * images.count+30, _scrollView.height);
    _scrollView.showsHorizontalScrollIndicator = NO;
    
    for (int i = 0 ; i < images.count; i++) {
        
        UIImageView *imageview = [[UIImageView alloc]initWithFrame:CGRectMake(i * (widht+3), 0, widht, _scrollView.height)];
        
        [imageview sd_setImageWithURL:[NSURL URLWithString:_datamodel.images[i]]];
        
        [_scrollView addSubview:imageview];
        
        
    }
    
    

}

#pragma mark --- Button按钮点击播放视屏方法
- (IBAction)sender:(UIButton *)sender {
    
    BaseNavigationController *baseNavigation = [UIApplication sharedApplication].keyWindow.rootViewController.childViewControllers[2];
    
    
    MPMoviePlayerViewController *mpmoviePlayerView = [[MPMoviePlayerViewController alloc]initWithContentURL:[NSURL URLWithString:@"http://vf1.mtime.cn/Video/2012/04/23/mp4/120423212602431929.mp4" ]];
    
    [baseNavigation presentMoviePlayerViewControllerAnimated:mpmoviePlayerView];
    
}



@end

//
//  PromoterViewController.m
//  Movie
//
//  Created by mac on 16/4/29.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "PromoterViewController.h"
#import "LastViewController.h"
@interface PromoterViewController ()<UIScrollViewDelegate>

@end

@implementation PromoterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self _createScrollView];
    
}

#pragma mark --- 启动页面
-(void)_createScrollView{
    //创建滑动视图
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    
    //滑动的内容尺寸(可以滑动多少张全屏大小的图片)
    scrollView.contentSize = CGSizeMake(KScreenwidh * 5, KScreenheight);
    //分页
    scrollView.pagingEnabled = YES;
    //是否显示滑动条
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.delegate = self;
    [self.view addSubview:scrollView];
    
    for (int i = 0; i < 5; i++) {
        
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(i *KScreenwidh, 0, KScreenwidh, KScreenheight)];
        
        imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"guide%d",i + 1]];
        
        [scrollView addSubview:imageView];
        
        
        UIImageView *pageImageView = [[UIImageView alloc]initWithFrame:CGRectMake((KScreenwidh - 173) / 2, KScreenheight - 50, 173, 26)];
        
        pageImageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"guideProgress%d",i + 1]];
        [imageView addSubview:pageImageView];
        
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{

    if(scrollView.contentOffset.x > KScreenwidh * 4){
    
    
        self.view.window.rootViewController = [[LastViewController alloc]init];
    
    
    }




}


@end

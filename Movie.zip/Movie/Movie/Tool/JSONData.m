//
//  JSONData.m
//  Movie
//
//  Created by mac on 16/4/19.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "JSONData.h"

@implementation JSONData

+(id)loadJSONData:(NSString *)fileName{

    //1.获取bundel中的数据
    NSString *JSONstring = [[NSBundle mainBundle]pathForResource:fileName ofType:@"json"];
    
    //2.将对应路径的JOSN文件转化成二进制文件
    NSData *JSONdata = [NSData dataWithContentsOfFile:JSONstring];
    //3.将JOSN文件转化成对象,创建一个字典存放对象.
    id dic = [NSJSONSerialization JSONObjectWithData:JSONdata options:NSJSONReadingMutableContainers error:nil];


    return dic;
}


@end

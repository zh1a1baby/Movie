//
//  JSONData.h
//  Movie
//
//  Created by mac on 16/4/19.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JSONData : NSObject
+(id)loadJSONData:(NSString *)fileName;

@end

//
//  MovieViewController.h
//  Movie
//
//  Created by mac on 16/4/18.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseViewController.h"

@interface MovieViewController : BaseViewController

@end

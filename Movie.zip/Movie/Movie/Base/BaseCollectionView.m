//
//  BaseCollectionView.m
//  Movie
//
//  Created by mac on 16/4/22.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseCollectionView.h"
#import "LargeConllctionFlowLayout.h"
#import "BaseCollectionViewFlowLayout.h"
@interface BaseCollectionView ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@end

@implementation BaseCollectionView

-(instancetype)initWithFrame:(CGRect)frame collectionViewLayout:(UICollectionViewLayout *)layout{
    
    self = [super initWithFrame:frame collectionViewLayout:layout];
    
    //判断,当self(本身对象)等于空的时候就设置一个代理,并注册单元格
    if(self){
        
        
        self.dataSource = self;
        self.delegate = self;
        
        self.decelerationRate = UIScrollViewDecelerationRateFast;
        self.showsHorizontalScrollIndicator = NO;

    }
    
    return self;
}

//单元格个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return _lagerViewcoll.count;
    
}

//返回单元格中的值
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    
    return nil;
    
    
}

-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset{
    
    //X轴的滑动位置 指针->
    float xoffset = targetContentOffset->x;
    
    //获取当前的活动对象
    BaseCollectionViewFlowLayout *flowLayouw =(BaseCollectionViewFlowLayout *)self.collectionViewLayout;
    
    float itemWith = flowLayouw.itemSize.width;
    
    //获取宽
    NSInteger pagWidht = itemWith + flowLayouw.minimumLineSpacing;
    
    //获取当前的页数
    NSInteger pagnum = (pagWidht/2 +xoffset)/pagWidht;
    
    //三目运算符计算X轴的位置当大于等于0的时候就可以加1进行滑动或者减1,
    pagnum = velocity.x == 0?pagnum:(velocity.x > 0)?pagnum+1:pagnum - 1;
    
    pagnum = MIN(MAX(pagnum, 0), _lagerViewcoll.count - 1);
    
    //中间的位置
    targetContentOffset->x = pagnum *pagWidht;


    self.crrentPath = pagnum;
    
    
}



@end

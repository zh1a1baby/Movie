//
//  BaseNavigationController.m
//  Movie
//
//  Created by mac on 16/4/18.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseNavigationController.h"

@interface BaseNavigationController ()

@end

@implementation BaseNavigationController

#pragma mark -- 设置导航栏
- (void)viewDidLoad {
    [super viewDidLoad];
//    //设置导航栏背景图片
    [self.navigationBar setBackgroundImage:[UIImage imageNamed:@"nav_bg_all-64"] forBarMetrics:UIBarMetricsDefault];

//    //修改导航栏字体
    //    //在plist中增加View并改为YES然后复写- (UIStatusBarStyle)preferredStatusBarStyle方法
    //修改导航栏样式
    self.navigationBar.barStyle = UIBarStyleBlack;
    
    //修改导航栏字体属性
    NSDictionary *dic = @{
                          
                          NSForegroundColorAttributeName:[UIColor whiteColor],
                          NSFontAttributeName:[UIFont systemFontOfSize:25]
                          
                          };
    //将字典里面的属性赋给titlextAttributex;
    self.navigationBar.titleTextAttributes = dic;
    
    //将透明度设置为不透明
    self.navigationBar.translucent = NO;
    

}

- (UIStatusBarStyle)preferredStatusBarStyle{

    return UIStatusBarStyleLightContent;
}

@end

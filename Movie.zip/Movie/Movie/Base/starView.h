//
//  starView.h
//  Movie
//
//  Created by mac on 16/4/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface starView : UIView

@property (assign,nonatomic)float staring;


@end

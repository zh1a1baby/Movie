//
//  starView.m
//  Movie
//
//  Created by mac on 16/4/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "starView.h"

@interface starView (){

    UIView *_grayView;
    UIView *_yellowView;

}

@end

@implementation starView




-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    
    if(self){
    
        [self _createView];
    
    }


    return self;

}

-(void)awakeFromNib{
    [super awakeFromNib];

    [self _createView];
}

-(void)_createView{


    // 设置星星图片
    UIImage *grayimage = [UIImage imageNamed:@"gray"];
    UIImage*yellowimage = [UIImage imageNamed:@"yellow"];
    
    //创建星星视图
    _grayView = [[UIView alloc]initWithFrame:CGRectMake(0, 0,grayimage.size.width*5, yellowimage.size.height)];
    _grayView.backgroundColor = [UIColor colorWithPatternImage:grayimage];
    [self addSubview:_grayView];
    
    _yellowView = [[UIView alloc]initWithFrame:CGRectMake(0, 0,yellowimage.size.width * 5, yellowimage.size.height)];
    _yellowView.backgroundColor = [UIColor colorWithPatternImage:yellowimage];
    [self addSubview:_yellowView];
    
    //对星星图片进行放大
    float scale = self.frame.size.height /_grayView.frame.size.height;
    
    _grayView.transform = CGAffineTransformMakeScale(scale, scale);
    _yellowView.transform = CGAffineTransformMakeScale(scale, scale);
    
    //将坐标放回原点
    _grayView.origin = CGPointZero;
    _yellowView.origin = CGPointZero;
    
//    float skt = [_cellModel.rating[@"average"] floatValue];
//    
//    yellowView.width = yellowView.width*(skt / 10.00);

}

-(void)setStaring:(float)staring{

    
    _staring = staring;
    
    _yellowView.width = _grayView.width*(staring/10.00);



}
@end

//
//  FoundTabBarButton.m
//  Movie
//
//  Created by mac on 16/4/18.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "FoundTabBarButton.h"

@implementation FoundTabBarButton

-(instancetype)initWithFrame:(CGRect)frame withImage:(NSString *)imageName withTitle:(NSString *)titleName{

    self = [super initWithFrame:frame];
    
    if(self != nil){
    
    
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake((self.frame.size.width-30)/2, 10, 30, 20)];
        
        imageView.image = [UIImage imageNamed:imageName];
        imageView.contentMode = UIViewContentModeScaleAspectFit;
        
        [self addSubview:imageView];
        
        UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(imageView.frame)+5, self.frame.size.width, 21)];
        //居中
        titleLabel.textAlignment = NSTextAlignmentCenter;
        //字体颜色
        titleLabel.textColor = [UIColor whiteColor];
        //文字大小
        titleLabel.font = [UIFont systemFontOfSize:14];
        //获取字符串内容
        titleLabel.text = titleName;
        [self addSubview:titleLabel];
        
    
    }



    return self;

}


@end

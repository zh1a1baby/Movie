//
//  BaseTabBarController.m
//  Movie
//
//  Created by mac on 16/4/18.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseTabBarController.h"
#import "FoundTabBarButton.h"
@interface BaseTabBarController (){

    UIImageView *_imageview;


}

@end

@implementation BaseTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self _removeTabBarButton];
    [self _createTabBarButton];
    
    
    
}
#pragma  mark -- 标签栏按钮
//判断在视图将要显示的时候在进行移除
-(void)viewWillAppear:(BOOL)animated{
    //程序加载完之后执行下面的方法
    [super viewWillAppear:YES];
    
    


}

//移除标签栏
-(void)_removeTabBarButton{

    
    
    //UITabBarButton是iOS框架私有的方法所以需要自己定义一个Class来取的这个方法
    Class class = NSClassFromString(@"UITabBarButton");
    
    //for容错处理
    
    //在这里不能移除标签栏上的按钮,移除之后还会加载他所管理的导航控制器,导航控制器会自动给她添加(创建上面的按钮)所以需要创建一个新的方法来判断当程序快执行完成的时候在走这里面的方法

    for (UIView *view in self.tabBar.subviews) {
        
        if([view isKindOfClass:class]){
            //使用遍历来判断是否当前取出的视图是不是我们像移除的
            [view removeFromSuperview];
        
        }
    }
}

//实现标签栏方法
-(void)_createTabBarButton{

    self.tabBar.translucent = NO;
    
    self.tabBar.backgroundImage = [UIImage imageNamed:@"nav_bg_all"];
    //创建Button坐标
    float titebutton = KScreenwidh/5;
    
     _imageview = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"selectTabbar_bg_all"]];
    
    _imageview.frame = CGRectMake(0, 0,titebutton - 15,TabBarHeight - 5);
    
    [self.tabBar addSubview:_imageview];
    

//    NSArray *titleButton = @[@"首页",@"新闻",@"Top250",@"影院",@"更多"];
    NSArray *titleButton = @[@"",@"",@"",@"",@""];

    NSArray *buttonImages = @[@"movie_home",@"msg_new",@"start_top250",@"icon_cinema.png",@"more_setting"];
    
    
    for (int i = 0; i < 5; i++) {
        
        //获取子类当中的属性
        FoundTabBarButton *foundButton =[[FoundTabBarButton alloc]initWithFrame:CGRectMake(i * titebutton, 0, titebutton, TabBarHeight) withImage:buttonImages[i] withTitle:titleButton[i]];
        
        foundButton.tag = i + 1000;
        
        
        [foundButton addTarget:self action:@selector(buttonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [self.tabBar addSubview:foundButton];
        
        if(i == 0){
        
            _imageview.center = foundButton.center;
            
        
        }
        
        
    }

}

-(void)buttonAction:(UIButton *)button{


    [UIView animateWithDuration:.5 animations:^{
        _imageview.center = button.center;
    }];
    
    self.selectedIndex = button.tag - 1000;
   

}
@end

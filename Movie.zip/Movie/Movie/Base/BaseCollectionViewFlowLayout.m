//
//  BaseCollectionViewFlowLayout.m
//  Movie
//
//  Created by mac on 16/4/23.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseCollectionViewFlowLayout.h"

@implementation BaseCollectionViewFlowLayout

-(instancetype)init{

    self = [super init];
    
    if (self != nil) {
        //小集合视图的滑动方向
        self.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        
        
    }

    return self;
    



}




@end

//
//  newsModel.m
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "NewsModel.h"

@implementation NewsModel
-(void)setValue:(id)value forUndefinedKey:(NSString *)key{

    if ([key isEqualToString:@"id"]) {
        _newsID = value;
    }


}





@end

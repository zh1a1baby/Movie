//
//  ImageModel.m
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ImageModel.h"

@implementation ImageModel



@end

//
//  ImageModel.h
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageModel : NSObject


@property (copy ,nonatomic)NSString *image;


@end

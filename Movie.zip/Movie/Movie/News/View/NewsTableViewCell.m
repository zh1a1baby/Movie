//
//  NewsTableViewCell.m
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "NewsTableViewCell.h"
#import "UIImageView+WebCache.h"
enum NewsType{
    kWordType,
    kImageType,
    kVideoType
};

@implementation NewsTableViewCell

-(void)setNewsDatamodel:(NewsModel *)newsDatamodel{
    _newsDatamodel = newsDatamodel;
    
    [_newsimages sd_setImageWithURL:[NSURL URLWithString:_newsDatamodel.image]];
    
    if ([_newsDatamodel.type integerValue] == 0) {
        
        _newsDatamodel.image = nil;
    //判断当_newsDatamodel.type转换之后等于1的时候就获取type文件中的类型是属于图片网页还是视屏网页,为1的时候属于图片
    }else if([_newsDatamodel.type integerValue] == 1){
    
        _newsType.image = [UIImage imageNamed:@"sctpxw"];
    //为2的时候是视屏(根据type文件中设置的ID判断数字)
    }else if([_newsDatamodel.type integerValue] == 2){
        
        _newsType.image = [UIImage imageNamed:@"scspxw"];

    }
    
    _titleLabel.text = _newsDatamodel.title;
    
    _newsSummary.text = _newsDatamodel.summary;
    
    
    
}

//- (void)layoutSubviews{
//
//    [super layoutSubviews];
//    
//    [_newsimages sd_setImageWithURL:[NSURL URLWithString:_newsDatamodel.image]];
//    
//}
@end

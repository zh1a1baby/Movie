//
//  NewsImageCollectionViewCell.h
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImageModel.h"
@interface NewsImageCollectionViewCell : UICollectionViewCell

@property (strong ,nonatomic)ImageModel *imagemodel;


@end

//
//  PhotoCell.h
//  Movie
//
//  Created by mac on 16/4/27.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ImageModel.h"
@interface PhotoCell : UICollectionViewCell

@property(strong ,nonatomic)ImageModel *photoModels;


@end

//
//  NewsImageCollectionViewCell.m
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "NewsImageCollectionViewCell.h"
#import "UIImageView+WebCache.h"

@interface NewsImageCollectionViewCell (){

   

}

@end


@implementation NewsImageCollectionViewCell



//set的方法复写Model获取Model中的数据并且实现
- (void)setImagemodel:(ImageModel *)imagemodel{
    _imagemodel = imagemodel;
    
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:self.contentView.bounds];
    
    [self.contentView addSubview:imageView];
    
    [imageView sd_setImageWithURL:[NSURL URLWithString:_imagemodel.image]];

    
}





@end

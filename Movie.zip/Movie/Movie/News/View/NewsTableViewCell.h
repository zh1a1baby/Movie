//
//  NewsTableViewCell.h
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsModel.h"
@interface NewsTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *newsimages;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *newsSummary;
@property (weak, nonatomic) IBOutlet UIImageView *newsType;

@property (strong ,nonatomic)NewsModel *newsDatamodel;

@end

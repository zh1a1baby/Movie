//
//  PhotoCell.m
//  Movie
//
//  Created by mac on 16/4/27.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "PhotoCell.h"
#import "UIImageView+WebCache.h"
@interface PhotoCell ()<UIScrollViewDelegate>{
    
    UIScrollView *_photoScollview;
    UIImageView *_imageView;


}
@end
@implementation PhotoCell

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];

    if(self != nil){
    
        [self _createScrollView];
    
    }

    return self;
}

#pragma mark --- 模态视图里面图片放大后需要实现的一些方法
-(void)_createScrollView{
    //滑动视图
    _photoScollview = [[UIScrollView alloc]initWithFrame:self.bounds];
    
    //图片放大缩小的最大倍数
    _photoScollview.minimumZoomScale = 0.5;
    _photoScollview.maximumZoomScale = 2;
    
    [self.contentView addSubview:_photoScollview];
    
    _photoScollview.tag = 1000;
    _photoScollview.delegate = self;
    
    //这个imageView的作用是接收传值并且实现的方法
    _imageView = [[UIImageView alloc]initWithFrame:self.bounds];
    
    //图片的自适应
    _imageView.contentMode = UIViewContentModeScaleAspectFit;
    
    [_photoScollview addSubview:_imageView];
    
    //添加手势的点击方法
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGesAction:)];
    [_photoScollview addGestureRecognizer:tapGesture];
    
    
    //添加双击手势
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGestureAction:)];
    //几根手指点击
    tapGestureRecognizer.numberOfTouchesRequired = 1;
    //点几次
    tapGestureRecognizer.numberOfTapsRequired = 2;
    
    [_photoScollview addGestureRecognizer:tapGestureRecognizer];
    
    //这个方法是,当存在两个点击方法的时候可以进行判断点击一次是一个手势,点击两次也是也是一个手势,不然两个方法手势会重叠,点击两次会执行点击两次的手势方法并且也会行一次的点击方法,这个方法的作用就是判断点击两次的时候不会执行点击一次的方法
    [tapGesture requireGestureRecognizerToFail:tapGestureRecognizer];
    

}

//获取模态过去的图片个数
- (nullable UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{

    return _imageView;


}

#pragma mark --- set方法获取Model的传值(模态点击过去的放大图片)
-(void)setPhotoModels:(ImageModel *)photoModels{

    _photoModels = photoModels;
    
    [_imageView sd_setImageWithURL:[NSURL URLWithString:_photoModels.image]];

  
}

-(void)tapGesAction:(UITapGestureRecognizer *)tapges{

    [[NSNotificationCenter defaultCenter] postNotificationName:@"tapGes" object:nil];



}

#pragma mark --- 点击放大缩小方法
-(void)tapGestureAction:(UITapGestureRecognizer *)tapGestureRecognizer{
    
    //如果没有放大点击两下就会放大两倍
    if(_photoScollview.zoomScale == 1){
    
        [_photoScollview setZoomScale:2 animated:YES];
    
    }else if(_photoScollview.zoomScale == 2){
        //如果是放大状态,点击两下就会回去原来的图片大小
        [_photoScollview setZoomScale:1 animated:YES];
    
    
    }
    
    
    
    
    

}

@end

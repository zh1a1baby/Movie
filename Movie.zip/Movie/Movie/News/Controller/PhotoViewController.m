//
//  PhotoViewController.m
//  Movie
//
//  Created by mac on 16/4/27.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "PhotoViewController.h"
#import "NewsImageCollectionViewCell.h"
#import "PhotoCell.h"
#define PhotoCellID @"PhotoCellID"


@interface PhotoViewController ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>{

    UICollectionView *_photoCollectionView;


}

@end

@implementation PhotoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //创建导航栏的Button按钮
    [self _createPhoto];
    //集合视图
    [self _createCollection];
    //滑动到点击的单元格位置
    [self _slideToSelectedLocation];

    //通知
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(targetAction) name:@"tapGes" object:nil];

}

#pragma mark --- 创建导航栏的Button按钮
-(void)_createPhoto{

    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(0, 0, 50, 30);
    [button setTitle:@"返回" forState:UIControlStateNormal];
    //点击事件
    [button addTarget:self action:@selector(PhotoAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *BarButton = [[UIBarButtonItem alloc]initWithCustomView:button];
    
    self.navigationItem.leftBarButtonItem = BarButton;
    
}

#pragma mark ---模态返回的方法
-(void)PhotoAction:(UIButton *)button{

    [self dismissViewControllerAnimated:YES completion:^{
        NULL;
    }];



}

#pragma mark --- 图片页面的集合视图
-(void)_createCollection{
    
    // 创建布局对象
    UICollectionViewFlowLayout *collectionView = [[UICollectionViewFlowLayout alloc]init];
    
    collectionView.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    collectionView.minimumLineSpacing = 0;
    
    collectionView.itemSize = CGSizeMake(KScreenwidh, KScreenheight - NavigationController);
    //创建集合视图
    _photoCollectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KScreenheight - NavigationController) collectionViewLayout:collectionView];
    _photoCollectionView.backgroundColor = [UIColor clearColor];
    
    //分页
    _photoCollectionView.pagingEnabled = YES;
    
    [self.view addSubview:_photoCollectionView];
    
    //设置代理
    _photoCollectionView.dataSource = self;
    _photoCollectionView.delegate = self;
    
    //注册单元格
    [_photoCollectionView registerClass:[PhotoCell class] forCellWithReuseIdentifier:PhotoCellID];
    
    
}

#pragma mark --- 集合视图代理的方法实现
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return _photoModel.count;

}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    PhotoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:PhotoCellID forIndexPath:indexPath];
    
    cell.photoModels = _photoModel[indexPath.item];
    
    
    return cell;


}

#pragma mark --- 滑到到我点击的那个单元格位置
-(void)_slideToSelectedLocation{
    //当我点击集合视图的图片时,点击哪一张就会模态进入那一张图片.
    NSIndexPath *indexPathScrollView = [NSIndexPath indexPathForItem:_index inSection:0];
    //让视图滑动到指定的位置
    [_photoCollectionView scrollToItemAtIndexPath:indexPathScrollView atScrollPosition:UICollectionViewScrollPositionNone animated:YES];

}

//当模态过去的图片被放大时然后需要滑动到下一张图片就会实现这个使图片恢复原本比例
-(void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    
    //强转获取不同类型的属性
    PhotoCell *photoCell = (PhotoCell *)cell;
    
    //从消失的item中取得滑动视图
    UIScrollView *photoScrollView = (UIScrollView *)[photoCell.contentView viewWithTag:1000];
    
    //让图片恢复比例
    [photoScrollView setZoomScale:1];

}

#pragma mark --- 接收通知后需要实现的方法
-(void)targetAction{
    
    if ( self.navigationController.navigationBar.hidden) {
        
        //判断导航栏在隐藏状态下,点击图片就会显示.
        [self.navigationController setNavigationBarHidden:NO animated:NO];
        _photoCollectionView.frame = CGRectMake(0, 0, KScreenwidh, KScreenheight - NavigationController);
        
    }else{
        
        //判断导航栏在显示状态下点击就会隐藏
        [self.navigationController setNavigationBarHidden:YES animated:NO];
        _photoCollectionView.frame = CGRectMake(0,NavigationController -10, KScreenwidh, KScreenheight - NavigationController);
        
    }
    

}


@end

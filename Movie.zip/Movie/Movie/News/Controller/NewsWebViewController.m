//
//  NewsWebViewController.m
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "NewsWebViewController.h"
#import "JSONData.h"
@interface NewsWebViewController ()<UIWebViewDelegate>{

    UIActivityIndicatorView *_activityIndicatorView;

}

@end

@implementation NewsWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
     "title" : "\"银河护卫队\"库珀配音浣熊 灭霸成反派幕后首脑",
     "content" :
     "time" : "2013-8-31 15:01:54",
     "source" : "Mtime时光网",
     "author" : "gmzyq 哈麦",
     */
    //解析数据
    NSDictionary *newsWebData = [JSONData loadJSONData:@"news_detail"];
    NSString *title = newsWebData[@"title"];//人物介绍
    NSString *content = newsWebData[@"content"];//文字内容
    NSString *author = newsWebData[@"author"];//演员
    NSString *source = newsWebData[@"source"];//年份
    NSString *time = newsWebData[@"time"];//来源
    
    //将来源和年份整合一下
    NSString *timeSource = [NSString stringWithFormat:@"年份是%@,来源是%@",time,source];
    //从本地加载html数据
    NSString *pathString = [[NSBundle mainBundle]pathForResource:@"news.html" ofType:nil];
    NSString *newsHtmlString = [NSString stringWithContentsOfFile:pathString encoding:NSUTF8StringEncoding error:nil];
    
    //将HTML的数据和html中需要展示的内容进行合并
    NSString *htmString = [NSString stringWithFormat:newsHtmlString,title,content,author,timeSource];
    
    //创建网页视图
    UIWebView *webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KScreenheight - NavigationController)];
    
//    webView.scalesPageToFit =  YES; //网页视图的自适应
    //代理方法
    webView.delegate = self;
    
    [self.view addSubview:webView];
    //网页视图加载html格式的字符串,并且进行显示
    [webView loadHTMLString:htmString baseURL:nil];
    
    //导航视图上的加载图标
    _activityIndicatorView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    UIBarButtonItem *activityItem = [[UIBarButtonItem alloc]initWithCustomView:_activityIndicatorView];
    
    self.navigationItem.rightBarButtonItem = activityItem;
    
    
}

#pragma mark --- 代理方法的实现
-(void)webViewDidStartLoad:(UIWebView *)webView{
    //开始旋转
    [_activityIndicatorView startAnimating];

}

-(void)webViewDidFinishLoad:(UIWebView *)webView{

    //结束旋转
    [_activityIndicatorView stopAnimating];

}


@end

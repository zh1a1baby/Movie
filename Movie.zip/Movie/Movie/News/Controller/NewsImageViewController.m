//
//  NewsImageViewController.m
//  Movie
//
//  Created by mac on 16/4/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "NewsImageViewController.h"
#import "JSONData.h"
#import "ImageModel.h"
#import "NewsImageCollectionViewCell.h"
#import "PhotoViewController.h"
#import "BaseNavigationController.h"
#import "PhotoViewController.h"
#define ImageCellID @"ImageCellID"
@interface NewsImageViewController ()<UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>{


    NSMutableArray *_newsDataArr;

}

@end

@implementation NewsImageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self _loadData];
    
    [self _ceaterImageController];
    

}

#pragma mark --- 解析数据
-(void)_loadData{
    //解析
    NSArray *DataArr = [JSONData loadJSONData:@"image_list"];
    _newsDataArr = [NSMutableArray array];
    
    for (NSDictionary *dic in DataArr) {
        
        ImageModel *imagmodel = [[ImageModel alloc]init];
        
        imagmodel.image =dic[@"image"];
        
        [_newsDataArr addObject:imagmodel];
        
    }
}

#pragma mark --- 创建集合视图
-(void)_ceaterImageController{

    // 创建布局对象
    UICollectionViewFlowLayout *collectionbView = [[UICollectionViewFlowLayout alloc]init];
    CGFloat itemWidth = (KScreenwidh - 5 * 10)/4;
    collectionbView.itemSize =CGSizeMake(itemWidth , itemWidth);
    
    //创建集合视图
    UICollectionView *imageView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, KScreenwidh, KScreenheight - NavigationController) collectionViewLayout:collectionbView];
    imageView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:imageView];
    
    imageView.delegate = self;
    imageView.dataSource = self;
    //注册单元格
    [imageView registerClass:[NewsImageCollectionViewCell class] forCellWithReuseIdentifier:ImageCellID];
    
    
    

}

#pragma mark --- 集合视图的代理方法实现
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{


    return _newsDataArr.count;

}

//获取数据并且传递给Model实现方法的内容
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{

    NewsImageCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ImageCellID forIndexPath:indexPath];
    cell.backgroundColor = [UIColor orangeColor];
    
    cell.imagemodel =_newsDataArr[indexPath.row];

    return cell;
}

//边框的间距
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{

    return UIEdgeInsetsMake(10, 10, 10, 10);
}

#pragma mark --- 创建一个模态过去的视图对象
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    //创建一个新的视图对象
    PhotoViewController *photoViewController = [[PhotoViewController alloc]init];
    
    //
    photoViewController.photoModel = _newsDataArr;
    photoViewController.index = indexPath.item;
    
    //创建导航栏
    BaseNavigationController *photoNavigetion = [[BaseNavigationController alloc]initWithRootViewController:photoViewController];
    //模态
    [self presentViewController:photoNavigetion animated:YES completion:^{
        NULL;
    }];



}





@end

//
//  PhotoViewController.h
//  Movie
//
//  Created by mac on 16/4/27.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseViewController.h"

@interface PhotoViewController : BaseViewController

@property (strong,nonatomic)NSArray *photoModel;
@property (assign,nonatomic)NSInteger index;


@end

//
//  NewsViewController.h
//  Movie
//
//  Created by mac on 16/4/28.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "BaseViewController.h"

@interface NewsViewController : BaseViewController

@end

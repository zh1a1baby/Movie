//
//  MiddleCollectionViewCell.m
//  Movie
//
//  Created by mac on 16/4/20.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "MiddleCollectionViewCell.h"
#import "UIImageView+WebCache.h"
#import "MovieView.h"

@interface MiddleCollectionViewCell (){

    UIImageView *_images;
    MovieView *_movieData;
    
}

@end

@implementation MiddleCollectionViewCell


-(instancetype)initWithFrame:(CGRect)frame{

    self = [super initWithFrame:frame];
    
    if(self){
        //设置单元格颜色
//        self.contentView.backgroundColor =[UIColor purpleColor];
        [self _ModelViewReceive];
        
        
        
    
    }

    return self;

}

-(void)_ModelViewReceive{

    _images = [[UIImageView alloc]initWithFrame:self.bounds];
    
    [self.contentView addSubview:_images];
    
    //关联XIP实现图片翻转,在MiddlevView设置点击时间
    _movieData = [[[NSBundle mainBundle]loadNibNamed:@"MovieView" owner:self options:nil] firstObject];
    //边框颜色
    _movieData.layer.cornerRadius = 1;
    _movieData.layer.borderWidth = 1;
    _movieData.layer.borderColor = [UIColor orangeColor].CGColor
    ;
    
    _movieData.hidden = YES;
    [self.contentView addSubview:_movieData];
    
    

}

-(void)setModelView:(MovieModel *)modelView{

    _modelView = modelView;
    NSURL *url = [NSURL URLWithString:_modelView.images[@"large"]];
    [_images sd_setImageWithURL:url];
    
    
    //获取MovieModel中的值
    _movieData.moviewmodel = _modelView;

}

-(void)cellFlip{
    
    //翻转动画
    UIViewAnimationOptions options = _movieData.hidden?UIViewAnimationOptionTransitionFlipFromLeft:UIViewAnimationOptionTransitionFlipFromRight;

    [UIView transitionWithView:self.contentView duration:.5 options:options animations:^{
        _images.hidden =! _images.hidden;
        _movieData.hidden =! _movieData.hidden;
        
        
    } completion:^(BOOL finished) {
        
    }];
}

-(void)resetcell{

    _images.hidden = NO;
    _movieData.hidden = YES;


}

@end

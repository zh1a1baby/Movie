//
//  CommontTableViewCell.m
//  Movie
//
//  Created by mac on 16/4/25.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "CommontTableViewCell.h"
#import "UIImageView+WebCache.h"
@implementation CommontTableViewCell


-(void)setCommonmodel:(CommonModel *)commonmodel{

    _commonmodel = commonmodel;
    
    [_useimageView sd_setImageWithURL:[NSURL URLWithString:_commonmodel.userImage]];
    
    _useLabel.text = _commonmodel.nickname;//名称
    
    _ratingLabel.text = _commonmodel.rating;//评分
    
    _commontLabel.text = _commonmodel.content;//评论

}




@end
